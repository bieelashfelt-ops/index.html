# Eclipse Backend V2

Backend mínimo para o Eclipse no Vercel.

## Arquivo necessário

- `api/chat.js`

O frontend atual do Eclipse já chama `POST /api/chat`, então basta adicionar esse arquivo ao mesmo repositório do `index.html`.

## Variável no Vercel

`OPENAI_API_KEY` — já deve estar cadastrada como Secret em Production.

Opcional:
`OPENAI_MODEL` — se não for configurada, o backend usa `gpt-6-luna`.

Não coloque a chave da OpenAI no GitHub.
